<?php 
	session_start();
	require_once "../models/db_project.php";

	//echo "hello";

	print_r($_POST);
	// exit;
	if(empty($_POST['customername'])){
		echo "customername";
	}
	elseif(empty($_POST['email'])){
		echo "email";
	}
	elseif(empty($_POST['mobile'])){
		echo "mobile";
	}
	elseif(empty($_POST['address'])){
		echo "address";
	}
	elseif(empty($_POST['job_title'])){
		echo "jobtitle";

	}

	elseif(empty($_POST['requirement'])){
		echo "requirement";
	}
	elseif(empty($_POST['location'])){
		echo "location";
	}
	elseif(empty($_POST['createdate'])){
		echo "create date";
	} 
	
	 else{
              $customername =($_POST['customername']);
              $email =($_POST['email']);
              $mobile=($_POST['mobile']);
              $address =($_POST['address']);
              $jobtitle =($_POST['job_title']);
              $requirement =($_POST['requirement']);
              $location =($_POST['location']);
              $createdate =($_POST['createdate']);
	          //echo  "$customername";
	 	$result=$obj->check_data($customername,$email,$mobile,$address,$jobtitle,$requirement,$location,$createdate);
		
	if($result[0]['cnt']>0){
	 		echo "name already eists";
	 	}
	 	else{

			if($obj->user($customername,$email,$mobile,$address,$jobtitle,$requirement,$location,$createdate)){
	 			echo "successfully added";
	 		}
	 	}
			
	 	 }
?>