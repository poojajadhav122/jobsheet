<?php 
	session_start();
	require_once "../models/db_project.php";

	//echo "hello";
	if(empty($_POST['customername'])){
		echo "enter customer name";	
	}
	else if(empty($_POST['email']))
	{
		echo "enter email";
	}
	else if(empty($_POST['mobile']))
	{
		echo "enter mobile";
	}
	else if(empty($_POST['address']))
	{
		echo "enter address";
	}
	else if(empty($_POST['jtitle']))
	{
		echo "enter jtitle";
	}
	else if(empty($_POST['requirement']))
	{
		echo "enter requirement";
	}
	else if(empty($_POST['location']))
	{
		echo "enter location";
	}
	else if(empty($_POST['createdate']))
	{
		echo "enter create date";
	} 
	else if(empty($_POST['allocatedate']))
	{
		echo "enter allocate date";
	}
	else{

		$customername=($_POST['customername']);
		$email=($_POST['email']);
		$mobile=($_POST['mobile']);
		$address=($_POST['address']);
		$jtitle=($_POST['jtitle']);
		$requirement=($_POST['requirement']);
		$location=($_POST['location']);
		$createdate=($_POST['createdate']);
		$allocatedate=($_POST['allocatedate']);
		//echo "$first";
		$result=$obj->admin_check_data($customername);
		
		if($result[0]['cnt']>0){
			echo "name already eists";
		}
		else{

			if($obj->admin_insert($customername,$email,$mobile,$address,$jtitle,$requirement,$location,$createdate,$allocatedate)){
				echo "successfully added";
			}
		}
			
		 }
?>