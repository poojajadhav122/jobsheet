<?php 
	//require_once "db_project.php";

	if(empty($_POST['ncustomername'])){
		echo "enter customer name";	
	}
	else if(empty($_POST['nemail']))
	{
		echo "enter email";
	}

	else if(empty($_POST['nmobile']))
	{
		echo "enter mobile";
	}

	else if(empty($_POST['naddress']))
	{
		echo "enter address";
	}
	else if(empty($_POST['njtitle']))
	{
		echo "enter jtitle";
	}
	else if(empty($_POST['nrequirement']))
	{
		echo "enter requirement";
	}
	else if(empty($_POST['nlocation']))
	{
		echo "enter location";
	}
	else{
		$dbcustomername=$obj->get_data($_SESSION['project_usemail']);
		echo $this->getUpdateData();
		// pre($_SESSION['']);
		// pre($dbcustomername);
	}

?>