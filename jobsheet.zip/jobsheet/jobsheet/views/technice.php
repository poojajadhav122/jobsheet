<?php
	
	require_once "../models/db_project.php";
	// require_once "admin_show_record.php";
?>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	<div class="container">

	<!-- <a href="index.php">Add record</a> -->
	<table class="table">
		<tr>
			<th>ID</th>
			<th>CUSTOMER NAME</th>
			<th>EMAIL</th>
			<th>MOBILE</th>
			<th>ADDRESS</th>
			<th>JOBTITLE</th>
			<th>REQUIREMENT</th>
            <th>LOCATION</th>
            <th>CREATE DATE</th>
            <th>ALLOCATE DATE</th>
            <th>ACCEPT DATE</th>
            <th>COMPLETE DATE</th>
			<!-- <th>ALLOCATE</th> -->
		</tr>

		<?php 
			$result=$obj->show_technice();	
			//print_r($result);
			if(is_array($result)):
				foreach ($result as $val): 
		?>
			<tr>
				<td><?php echo $val['id'] ?></td>
				<td><?php echo $val['customername'] ?></td>
				<td><?php echo $val['email'] ?></td>
				<td><?php echo $val['mobile']?></td>
				<td><?php echo $val['address']?></td>
				<td><?php echo $val['jobtitle']?></td>
				<td><?php echo $val['requirement']?></td>
				<td><?php echo $val['location']?></td>
				<td><?php echo $val['createdate']?></td>
				<td><?php echo $val['allocatedate']?></td>
				<td><?php echo $val['acceptdate']?></td>
				<td><?php echo $val['completedate']?></td>

	<!-- <a href="../controller/accept_record_action.php?ab=<?php echo $val['id']?>"> ACCEPT</a><td>
     -->        <!--  <form action="accept_record_action.php" method="post">
             	<input type="hidden" name="id" value="<?php echo $val['id']?>">
             	<button name="btn_accept">
					ACCEPT
				</button>
			</form> -->
					</td>
					<td><a href="accept_record.php?ab=<?php echo $val['id']?>">ACCEPT</a></td>
				<td><a href="cancel_record.php?ab=<?php echo $val['id']?>">CANCEL
				</a></td>
 
			</tr>
			<?php 
				endforeach;
			endif;
			?>
			
		
	</table>
</div>