<!-- <?php
///require_once "admin.php";

?>
 -->
<div class="mainmenu pull-left">

                            <ul class="nav navbar-nav collapse navbar-collapse">
                                <!-- <li><a href="index.php" class="active">Home</a></li> -->
                                <li class="dropdown"><a href="#">LOGIN<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">

                                  <?php 
                                  //pre($_SESSION);
                                    if(!isset($_SESSION['project_usname'])):

                                  ?>
                                <li><a href="login.php">login
                                 
                                </a></li>
                                <?php 
                                    endif;
                                ?>
                                <?php 
                                    if(isset($_SESSION['project_usname'])):
                                ?>
                                <!-- <li><a href="shop.php">forgot password</a></li> -->
                                <li><a href="logout.php">logout</a></li>
                                                               <li><a href="#">Welcome (<?php echo $_SESSION['project_usname']; ?>)</a></li>
                                <?php 
                                    endif;
                                ?>
                                        
                                    </ul>
                                </li> 
                               
                            </ul>
                        </div>
