<?php 
	require_once "../models/db_project.php";

	//echo $id=$_GET['ab'];
	$obj=new db_project();
		if(isset($_GET['ab'])){
		//$whr = "id=".$_GET['ab'];
		$conn=mysqli_query("select * from record id=".$_GET['ab']);
		$row=mysqli_fetch_array($conn);
	}
?>


<div class="container">
	<form id="update_form" method="post" action="update-action.php?id=<?php echo $_GET['id']?>">
	<label>CUSTOMER NAME</label>
	<input type="text" value="<?php echo $row['customername']?>" name="ncustomername" placeholder="Enter customer name" >
	<br>
	<label> EMAIL</label>
	<input type="text" value="<?php echo $row['email']?>" name="nemail" placeholder="Enter email">
	<br>
	<label>MOBILE</label>
	<input type="text" value="<?php echo $row['mobile']?>" name="nmobile" placeholder="Enter mobile">
	<br>
	<label>ADDRESS</label>
	<input type="text" value="<?php echo $row['address']?>" name="naddress" placeholder="Enter address">
	<br>
	<label>JOBTITLE</label>
	<input type="text" value="<?php echo $row['jobtitle']?>" name="njobtitle" placeholder="Enter jobtitle">
	<br>
	<label>REQUIREMENT</label>
	<input type="text" value="<?php echo $row['requirement']?>" name="nrequirement" placeholder="Enter requirement">
	<br>
	<label>LOCATION</label>
	<input type="text" value="<?php echo $row['location']?>" name="nlocation" placeholder="Enter location">
	<br>
	<label>CREATEDATE</label>
	<input type="text" value="<?php echo $row['createdate']?>"name="ncreatedate" placeholder="Enter create date" >
	<br>
	<label>ALLOCATE DATE</label> 
	<input type="text"  value="<?php echo $row['allocatedate']?>" name="nallocatedate" placeholder="Enter allocate date">
	<br>
	<label>ACCEPT DATE</label>
	<input type="text" name="nacceptdate" placeholder="Enter accept date">
	<br>
	<label>COMPLETE DATE</label>
	<input type="text" name="ncompletedate" placeholder="Enter complete date">
    <br>
	<button type="button" class="btn-update">update</button>
	<div class="msg_form"></div>
	</form>
	<!-- <a href="show_record.php">Show records</a> -->
</div>