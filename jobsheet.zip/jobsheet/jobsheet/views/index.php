<?php   
    
    require_once "../models/db_project.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
      <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/prettyPhoto.css" rel="stylesheet">
    <link href="../assets/css/price-range.css" rel="stylesheet">
    <link href="../assets/css/animate.css" rel="stylesheet">
    <link href="../assets/css/main.css" rel="stylesheet">
    <link href="../assets/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="../assets/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
    <header id="header"><!--header-->
       
        <div class="header-bottom"><!--header-bottom-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-9">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="mainmenu pull-left">
                            <ul class="nav navbar-nav collapse navbar-collapse">
                                <!-- <li><a href="index.php" class="active">Home</a></li> -->
                                <li class="dropdown"><a href="#">LOGIN<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">

                                  <?php 
                                  //pre($_SESSION);
                                    if(!isset($_SESSION['project_usname'])):

                                  ?>
                                <li><a href="login.php">login</a></li>
                                <?php 
                                    endif;
                                ?>
                                <?php 
                                    if(isset($_SESSION['project_usname'])):
                                ?>
                                <!-- <li><a href="shop.php">forgot password</a></li> -->
                                <li><a href="logout.php">logout</a></li>
                                                               <li><a href="#">Welcome (<?php echo $_SESSION['project_usname']; ?>)</a></li>
                                <?php 
                                    endif;
                                ?>
                                        
                                    </ul>
                                </li> 
                               
                            </ul>
                        </div>
                    </div>
                                   </div>
            </div>
        </div><!--/header-bottom-->
    </header><!--/header-->
        <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.scrollUp.min.js"></script>
    <script src="../assets/js/price-range.js"></script>
    <script src="../assets/js/jquery.prettyPhoto.js"></script>
    <script src="../assets/js/main.js"></script>
   
    <script src="../assets/js/jobsheet.js"></script>

    <?php 
        if(isset($_SESSION['project_usname'])):
    ?>
       <?php
    endif; 
    ?>
</body>
</html>