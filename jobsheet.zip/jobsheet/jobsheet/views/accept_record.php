<?php 
	require_once "../models/db_project.php";

	$id=$_GET['ab'];
	//echo "$id";
	$result=$obj->accept_records($id);
	print_r($result);
	if($result){
	 	header("location:admin_show_record.php");

	 }
?>
