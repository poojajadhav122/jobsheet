<?php 
	require_once "../models/db_project.php";
//require_once "index.php";
	require_once "admin_loginpage.php";
?>
<div class="container">
	<form id="main_form" method="post" >
	<label>CUSTOMER NAME</label>
	<input type="text" name="customername"  placeholder="Enter customer name">
	<br>
	<br>
	<label> EMAIL</label>
	<input type="text" name="email" placeholder="Enter email">
	<br>
	<br>
	<label>MOBILE</label>
	<input type="text" name="mobile" placeholder="Enter mobile ">
	<br>
	<br>
	<label>ADDRESS</label>
	<input type="text" name="address" placeholder="Enter address">
	<br>
	<br>
	<label>JOB TITLE</label>
	<input type="text" name="job title" placeholder="Enter job title">
	<br>
	<br>
	<label>REQUIREMENT</label>
	<input type="text" name="requirement" placeholder="Enter requirement">
    <br>
    <br>
    <label>LOCATION</label>
    <input type="text" name="location" placeholder="Enter location">
    <br>
    <br>
    <label>CREATE DATE</label>
    <input type="text" name="createdate" placeholder="Enter create date">
    <br>
    <br>
    <label>ALLOCATE DATE</label>
    <input type="text" name="allocatedate" placeholder="Enter allocate date">
    <br>
    <br>
	<button type="button" class="btn">enter</button>
	<div class="msg_form"></div>
	</form>
	<a href="admin_show_record.php">Show records</a>
</div>
