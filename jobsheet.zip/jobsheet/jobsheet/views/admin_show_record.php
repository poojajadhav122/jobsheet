<?php
	
	require_once "../models/db_project.php";

	require_once "index.php";
?>
	<!-- <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
 -->	<div class="container">

	<a href="admin.php">Add record</a>
	<table class="table">
		<tr>
			<th>ID</th>
			<th>CUSTOMER NAME</th>
			<th>EMAIL</th>
			<th>MOBILE </th>
			<th>ADDRESS</th>
			<th>JOB TITLE</th>
			<th>REQUIREMENT</th>
			<th>LOCATION</th>
			<th>CREATE DATE</th>
			<th>ALLOCATE DATE</th>
			<th>DELETE</th>
		</tr>

		<?php 
			$result=$obj->show_record();	
			//print_r($result);
			if(is_array($result)):
				foreach ($result as $val): 
		?>
			<tr>
				<td><?php echo $val['id'] ?></td>
				<td><?php echo $val['customername'] ?></td>
				<td><?php echo $val['email']?></td>
				<td><?php echo $val['mobile']?></td>
				<td><?php echo $val['address']?></td>
				<td><?php echo $val['jobtitle']?></td>
				<td><?php echo $val['requirement']?></td>
				<td><?php echo $val['location']?></td>
				<td><?php echo $val['createdate']?></td>
				<td><?php echo $val['allocatedate']?></td>
				<td><a href="delete_record.php?ab=<?php echo $val['id']?>"> Delete
				</a></td>
				<td><a href="update_record.php?ab=<?php echo $val['id']?>">EDIT
				</a></td>

			</tr>
			<?php 
				endforeach;
			endif;
			?>
			
		
	</table>
</div>