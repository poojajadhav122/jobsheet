<?php 

	if(session_id()== ""){
		session_start();
		//echo session_id();
	}

	 require_once "db_function.php";
	 interface db_parameter{
	 	const HOSTNAME = "localhost";
	 	const  USER= "root";
	 	const  PASSWORD= "";
	 	const DATABASE = "jobsheet";
	 }

	 interface db_general_function{

	function insert($table,$columns,$values);
 	function update($table,$columns,$condition);
 	function delete($table,$condition);
 	function select($col,$tab,$condition);
	 
	 }


?>