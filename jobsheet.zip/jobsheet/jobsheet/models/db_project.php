<?php  

	require_once "db_helper.php";

	final class db_project extends db_helper{
		
		function check_email_count($email){

			//echo $email;
			//select count(*) from users where us_email="$email"
 
			return self::select(
			"count(*) as cnt","users","us_email='$email'"
		);

		}

		function user_insert($name,$mobile,$email,$password){

			return parent::insert(
				"users",
				"us_name,us_mobile,us_email,us_password",
				"'$name','$mobile','$email','$password'"
			);
		}

		function get_user_data($email){
			//echo email;
			return db_helper::select(
		"*","users","us_email='$email'"
			);
		}

		function get_password_userwise($email){

			return db_helper::select(
				"us_password","users","us_email='$email'");
		}
		function update_password($pass,$email){
			//update users set us_password ='$newpass' where us_email='$email'
			return $this->update("users","us_password='$pass'","us_email='$email'");
		}

		function show_record(){
		 	return parent::select("*","record","1");
		 }
		 function admin_show_record(){
		 	return parent::select("*","record","1");
		 }
              function admin_check_data($customername){
			return parent::select("*","record","customername='$customername'");
		}
		 function check_data($customername,$email,$mobile,$address,$jobtitle,$requirement,$location,$createdate){
			
			return parent::select("*","record","customername='$customername' and email='$email'");
		}
		function user($customername,$email,$mobile,$address,$jobtitle,$requirement,$location,$createdate){

		 	return db_helper::insert(
		 		"record","customername,email,mobile,address,jobtitle,requirement,location,createdate","'$customername','$email','$mobile','$address','$jobtitle','$requirement','$location','$createdate'");
		 }
		 // function admin($customername,$email,$mobile,$address,$jobtitle,$requirement,$location,$createdate,$allocatedate){
		 // 	return db_helper::insert(
   //            "record","customername,email,mobile,address,jobtitle,requirement,location,createdate,allocatedate","'$customername','$email','$mobile','address','jobtitle','requirement','location','createdate','allocatedate'"
		 // 	);
		 // }
		 function admin_insert($customername,$email,$mobile,$address,$jobtitle,$requirement,$location,$createdate,$allocatedate){
		 	return db_helper::insert(
		 		"record","customername,email,mobile,address,jobtitle,requirement,location,createdate,allocatedate","'$customername','$email','$mobile','$address','$jobtitle','$requirement','$location','$createdate',$allocatedate'");
		 }
	     function delete_records($data){
		 	//delete from brands where id=3;
		 return parent::delete("record","id='$data'");
		 }
           
         function show_technice(){
		 	return parent::select("*","record","1");
		 }		 
   	   
   	     function accept_records(){
   	     	return parent::select("*","record","1");
   	     }
   	     function getUpdateData($customername,$email,$mobile,$address,$jobtitle,$requriement,$location,$createdate,$allocatedate){
   	     	return parent::update("record","customername,email,mobile,address,jobtitle,requirement,location,createdate,allocatedate","'$customername','$email','$mobile','$address','$titlejob','$requirement','$location','$createdate','$allocatedate'where id='.$id'"); 
   	     }
   }
	$obj=new db_project();



	?>
