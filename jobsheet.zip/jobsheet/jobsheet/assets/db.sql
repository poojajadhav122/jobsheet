create database jobsheet;
create table users(

	us_id int auto_increment primary key,
	us_name varchar(100),
	us_mobile bigint,
	us_email varchar(100),
	us_password varchar(100),
	us_time timestamp

);
create table record(
id int auto_increment primary key,
customername varchar(100),
email varchar(100),
mobile varchar(20),
address varchar(100),
jobtitle varchar(100),
requirement varchar(100),
location varchar(100)
);

create table record(
	id int auto_increment primary key,
	first text,
	last text
);

