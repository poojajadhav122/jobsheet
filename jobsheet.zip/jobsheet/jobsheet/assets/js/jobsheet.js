$(document).ready(function(){
	//alert(1);
	$(".btn-login").click(function(){
		//alert(1);
		record = $("#login_form").serialize();
		//console.log(record);
		$.post("../controllers/login-action.php",record).success(
			function(response){

				if(response=="ok"){
					window.location.href="index.php";
				}
				else{
					$(".msg_login").html(response);
				}
			})

	})

	$(".btn-register").click(function(){
		//alert(1);
		record = $("#register_form").serialize();
		//console.log(record);
		$.post("../controllers/register-action.php",record).success(
		function(response){

		$(".msg_register").html(response);
		})

	})


	$("#main_form").click(function(){
			record = $("#main_form").serialize();
			console.log(record);
			$.post("../controllers/add-record-action.php",record).success(
			function(response){
				
				//alert(response);
				if(response=="ok"){
			        alert(response)
					window.location.href="show_record.php";
				}
				else{
					$(".msg_form").html(response);
				}
			});
	});


	$(".btn").click(function(){
			//alert(2);
			record = $("#main_form").serialize();
			console.log(record);
			$.post("../controllers/admin_add_record_action.php",record).success(
			function(response){
				if(response=="ok"){
					window.location.href="show_record.php";
				}
				else{
					$(".msg_form").html(response);
				}
			})
		});

	$(".btn").click(function(){
			//alert(2);
			record = $("#update_form").serialize();
			console.log(record);
			$.post("../controllers/update-action.php",record).success(
			function(response){

				if(response=="ok"){
					window.location.href="show_record.php";
				}
				else{
					$(".msg_form").html(response);
				}
			})
		});



});
